// Behavior Data -- Compiled using CSocket -- //
var storage = {};

exports.Set_Variable = function (variable, scope, value) {
  try {
    storage[variable] = value;
  } catch (e) {
    return;
	}
	storage[variable] = value;
	return;
};
exports.Get_Variable_Value = function (variable, scope, default_value) {
  if (typeof storage[variable] !== 'undefined') {
	return {"Value": storage[variable]}} else
	{ 
    return {"Value": default_value};
	}
};
exports.Clear_Variables = function (scope) {
    storage = {};
    console.log("Cleared variables in: " + scope);
};
exports.Destroy_Variable = function (variable) {
  if (storage[variable] !== undefined) {
	delete storage[variable];
	return {"Success": true};
	} else
  return {"Success": false};
};
exports.Test_for_Variable = function (variable) {
  if (storage[variable] !== undefined) {
	return {"Exists":true};
	} else
  return {"Exists":false};
};

exports.Get_Variables = function () {
  return {"Variables":Object.keys(storage)};
};
exports.Get_Variable_Count = function () {
  return {"Count":Object.keys(storage).length};
};
